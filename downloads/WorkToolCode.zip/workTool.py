import tkinter as tk
from tkinter import *
from tkinter import ttk
from datetime import date
import random
import pyperclip as pc

# main frame
frame = tk.Tk()
frame.title("New Starter")
frame.geometry('400x600')

#create notebook
notebook = ttk.Notebook(frame) 

#NEW STARTER TAB

#generate newStarterTab and add it to notebook
newStarterTab = Frame(notebook)
notebook.add(newStarterTab,text="New Starter")

#LOGIC
#function to take the user input
def getInput():
    inp = srContent.get(1.0, "end-1c")
    sr = srInput.get(1.0, "end-1c")
    processInput(inp, sr)

#function to clear the content
def clearSRText():
    srInput.delete(1.0, 'end')
    srContent.delete(1.0, 'end')
    outputField.delete(1.0, 'end')
    ADfield.delete(1.0, 'end')

#function to process input
def processInput(inp, sr):

    #clear field
    outputField.delete(1.0,'end')

    #turn text into separate lines
    parsedInp = inp.splitlines()

    result = "New Starter\n" + sr + "\n"

    #define email extension
    emailExtension = '@equans.com'

    #create AD note
    AD = "New Starter - " + date.today().strftime("%d/%m/%Y") + " - " + sr

    #attach AD note to text widget
    ADfield.insert("1.0",AD)

    #array with the criteria
    criteria = {"First name","Surname","Employee number", "Employment type", "Start date", "End date", "Line manager","Job title","Primary site" }

    #loop through the criteria array 
    for elm in parsedInp:
        if elm in criteria:
            if elm == "Start date":
                index = parsedInp.index(elm)
                result += "SD: " + parsedInp[index+1] + "\n"
            elif elm == "End date":
                index = parsedInp.index(elm)
                result += "ED: " + parsedInp[index+1] + "\n"
            elif elm == "First name":
                index = parsedInp.index(elm)
                result +=parsedInp[index+1] + "\n"
                firstName = parsedInp[index+1]
            elif elm == "Surname":
                index = parsedInp.index(elm)
                result +=parsedInp[index+1].upper() + "\n"
                lastName = parsedInp[index+1]

                #generate email address
                email = firstName.lower() + "." + lastName.lower() + emailExtension
                result += email + "\n"

            else:
                index = parsedInp.index(elm)
                result += parsedInp[index+1] + "\n"


    #attach formatted string to text widget
    outputField.insert('1.0',result)

    #copy to clipboard
    pc.copy(result)

#VISUALS
# sr label
srLabel = tk.Label(newStarterTab, text = "Service Request Number")
srLabel.pack()

# sr number input
srInput = tk.Text(newStarterTab,height = 1, width = 10)
srInput.pack()

# content label
contentLabel = tk.Label(newStarterTab, text = "Content")
contentLabel.pack()

# input content
srContent = tk.Text(newStarterTab, height = 5, width = 20)
srContent.pack()

# generate button
printButton = tk.Button(newStarterTab,text = "Generate", command = getInput)
printButton.pack()

# parsed input text field
outputField = tk.Text(newStarterTab,height = 15, width = 35)
outputField.pack()

# sr label
srLabel = tk.Label(newStarterTab, text = "AD Telephone Tab")
srLabel.pack()

# AD notes comment
ADfield = tk.Text(newStarterTab,height = 1, width = 35)
ADfield.pack()

# clear button
clearButton = tk.Button(newStarterTab,text = "Clear", command = clearSRText, anchor="w")
clearButton.pack()


#PASSWORD GENERATOR TAB
#LOGIC

#generate passTab and add it to notebook
passTab = Frame(notebook)
notebook.add(passTab,text="Password Generator")
#check if the initials are in the right format
def checkInitials(x):
    verify = [*x]

    if x == "":
        return "ib"
    elif len(verify) == 2:
        return x
    else:
        return 'Wrong'

#generate the password
def generatePassword():

    #clear field
    clearPassText()

    #today's date
    tDate = date.today()

    #dictionary with the days of the week
    weekDays = {
        0:"MON",
        1:"TUE",
        2:"WED",
        3:"THU",
        4:"FRI",
        5:"SAT",
        6:"SUN"
    }

    #dictionary with the months
    months = {
        1:"JAN",
        2:"FEB",
        3:"MAR",
        4:"APR",
        5:"MAY",
        6:"JUN",
        7:"JUL",
        8:"AUG",
        9:"SEP",
        10:"OCT",
        11:"NOV",
        12:"DEC"
    }

    randomSymbol = ['@','#','$','%','&','!','.','?']

    inp = initialsField.get(1.0, "end-1c")

    dayOfTheWeek = weekDays[tDate.weekday()]

    monthOfTheYear = months[tDate.month]

    dayOfTheMonth = tDate.day

    if(dayOfTheMonth < 10):
        dayOfTheMonth = "0" + str(tDate.day)

    pws = dayOfTheWeek + str(dayOfTheMonth) + monthOfTheYear + str(tDate.year) + checkInitials(inp) + random.choice(randomSymbol)

    passField.insert('1.0',pws)

    pc.copy(pws)

#clear password field
def clearPassText():
    passField.delete(1.0,'end')

#VISUALS
# password label
passLabel = tk.Label(passTab, text = "Password")
passLabel.pack()

# password field
passField = tk.Text(passTab,height = 1, width = 40)
passField.pack()

# initials label
initialsLabel = tk.Label(passTab, text = "Initials")
initialsLabel.pack()

# initials field
initialsField = tk.Text(passTab,height = 1, width = 10)
initialsField.pack()

# generate button
generateButton = tk.Button(passTab,text = "Generate & Copy", command = generatePassword, anchor="w")
generateButton.pack()

#pack the notebook
notebook.pack(expand=True, fill=BOTH)

#main
frame.mainloop()

